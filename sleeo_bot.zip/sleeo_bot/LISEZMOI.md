# Sleeo Watch : installation (GitHub privé + Render)

## 1. Les fichiers du dossier
- bot.py : le bot
- keep_alive.py : le mini-site qui garde Render éveillé
- requirements.txt : les paquets Python
- .env.example : le modèle des variables (NE PAS mettre de vraies valeurs dedans)
- .gitignore : empêche d'envoyer .env sur GitHub

## 2. Préparer Discord
1. discord.com/developers > ton application > Bot : active "Message Content Intent".
2. Réinitialise le token du bot si tu l'as déjà posté quelque part.
3. Invite le bot sur ton serveur avec ces droits : Voir les salons, Envoyer des messages, Intégrer des liens, Lire l'historique, Gérer les salons.
4. Dans le serveur, place le rôle du bot au-dessus des rôles membres.
5. La catégorie des salons perso doit s'appeler exactement : 🎯・𝗙𝗶𝗹𝘁𝗿𝗲𝘀-𝗽𝗲𝗿𝘀𝗼

## 3. GitHub (privé)
1. github.com > New repository > nom sleeo-bot > coche Private.
2. Add file > Upload files : dépose bot.py, keep_alive.py, requirements.txt, .gitignore et .env.example.
3. Ne dépose JAMAIS un fichier .env avec de vraies clés.

## 4. Render
1. render.com > New > Web Service > connecte GitHub > choisis sleeo-bot.
2. Language : Python. Build Command : pip install -r requirements.txt
3. Start Command : python bot.py
4. Environment Variables (onglet Environment) :
   - DISCORD_BOT_TOKEN = le token du bot
   - SUPABASE_URL = https://xxxx.supabase.co
   - SUPABASE_SERVICE_KEY = la clé service_role (Supabase > Settings > API). SECRÈTE.
   - SITE_URL = l'adresse de ton site
   - CHECK_INTERVAL = 30
   - (si le build échoue à cause de la version de Python) PYTHON_VERSION = 3.12.3
5. Deploy. Dans Logs, tu dois voir : "Connecté : NomDuBot".

## 5. Le garder éveillé
Un service web gratuit de Render peut s'endormir sans visites. Crée un moniteur gratuit (par exemple UptimeRobot) qui ouvre l'adresse Render toutes les 5 minutes. Vérifie les règles actuelles de Render pour l'offre gratuite.

## 6. Premier test
1. Dans Discord, tape !setup dans un salon (admin).
2. Relie ton compte : sur le site, Mon compte > Connecter Discord. Pour tester sans le site, lance dans Supabase :
   update profiles set discord_id = 'TON_ID_DISCORD' where id = 'TON_ID_UTILISATEUR';
   (ID Discord : Paramètres > Avancés > Mode développeur, puis clic droit sur ton profil > Copier l'identifiant)
3. Donne-toi le module : insert into entitlements(user_id, module_key, source) values ('TON_ID_UTILISATEUR','bot_adv','admin');
4. Clique Ajouter un filtre, colle un lien de recherche Vinted. Les nouvelles annonces arrivent sans les anciennes.

## Si ça ne marche pas
- "Variables manquantes" : une variable d'environnement n'est pas remplie sur Render.
- Les boutons ne répondent pas : le bot n'est pas connecté, regarde les Logs.
- "Relie d'abord ton compte" : discord_id absent dans profiles.
- Plus rien n'arrive : Vinted a peut-être bloqué les requêtes, augmente CHECK_INTERVAL.
